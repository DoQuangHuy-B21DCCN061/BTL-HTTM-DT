package com.example.demo.entity;

import lombok.Data;

@Data
public class CapNhatSoLuongRequest {
    private Integer productId;
    private int quantity;
}
