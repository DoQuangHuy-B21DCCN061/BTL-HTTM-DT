// AuthController.java
package com.example.demo.auth;

import com.example.demo.entity.NhanVien;
import com.example.demo.entity.KhachHang;
import com.example.demo.repository.NhanVienRepo;
import com.example.demo.repository.KhachHangRepository;
import com.example.demo.service.NhanVienService;
import com.example.demo.service.KhachHangService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.util.Date;

@Controller
public class AuthController {

    @Autowired
    private NhanVienService nhanVienService;

    @Autowired
    private NhanVienRepo nhanVienRepo;

    @Autowired
    private KhachHangService khachHangService;

    @Autowired
    private KhachHangRepository khachHangRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/login")
    public String form() {
        return "login/auth";
    }

    @GetMapping("/home")
    public String login() {
        return "admin/trang_chu";
    }

    @GetMapping("/register")
    public String register() {
        return "login/register";
    }

    @PostMapping("/register")
    public String registerPost(@RequestParam String username,
                             @RequestParam String email,
                             @RequestParam String password,
                             @RequestParam String confirmPassword,
                             RedirectAttributes redirectAttributes) {
        
        // Kiểm tra xem username đã tồn tại chưa
        if (khachHangRepository.findByTaiKhoan(username).isPresent()) {
            redirectAttributes.addFlashAttribute("error", "Username đã tồn tại!");
            return "redirect:/register";
        }

        // Kiểm tra password và confirmPassword có khớp không
        if (!password.equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("error", "Mật khẩu không khớp!");
            return "redirect:/register";
        }

        // Tạo mới đối tượng KhachHang
        KhachHang khachHang = new KhachHang();
        khachHang.setTaiKhoan(username);
        khachHang.setEmail(email);
        khachHang.setMatKhau(passwordEncoder.encode(password));
        khachHang.setRole("KHACHHANG");
        khachHang.setIsRegistered(true);
        khachHang.setNgayDangKy(new Date());

        // Lưu khách hàng vào database
        khachHangRepository.save(khachHang);

        // Chuyển hướng về trang đăng nhập
        redirectAttributes.addFlashAttribute("success", "Đăng ký thành công! Vui lòng đăng nhập.");
        return "redirect:/login";
    }

//    @PostMapping("/login")
//    public String login1(@RequestBody NhanVien nv) {
//        return nv.getUsename() nv.getPassword();
//    }

}
